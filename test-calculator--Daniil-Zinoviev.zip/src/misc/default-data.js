export const buildings = [
  {
    title: "Жилой дом",
    value: 1
  },
  {
    title: "Гараж",
    value: 2
  },
];

export const materials = [
  {
    title: "Кирпич",
    value: 1
  },
  {
    title: "Шлакоблок",
    value: 2
  },
  {
    title: "Деревянный брус",
    value: 3
  },
  // {
  //   title: "Металл",
  //   value: 4
  // },
  // {
  //   title: "Сендвич-панели",
  //   value: 5
  // },
]