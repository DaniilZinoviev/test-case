import { buildings, materials } from "./default-data";

export { buildings, materials };
